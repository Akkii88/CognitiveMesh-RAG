"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Network, Cpu, Shield } from "lucide-react"
import type { TerminalLine } from "./crt-terminal"

interface InputSectionsProps {
  onAddLines: (lines: TerminalLine[]) => void
  setIsTyping: (typing: boolean) => void
}

export function InputSections({ onAddLines, setIsTyping }: InputSectionsProps) {
  // Persona Router state
  const [postContent, setPostContent] = useState("")
  const [threshold, setThreshold] = useState([0.2])

  // Content Engine state
  const [selectedBot, setSelectedBot] = useState("")

  // RAG Defense state
  const [parentPost, setParentPost] = useState("")
  const [commentHistory, setCommentHistory] = useState("")
  const [latestReply, setLatestReply] = useState("")

  const simulateTyping = async (lines: TerminalLine[], delayBetween = 400) => {
    setIsTyping(true)
    for (const line of lines) {
      await new Promise((resolve) => setTimeout(resolve, delayBetween + Math.random() * 200))
      onAddLines([line])
    }
    setIsTyping(false)
  }

  const handleRoute = async () => {
    if (!postContent.trim()) return

    const lines: TerminalLine[] = [
      { text: "receiving input...", type: "system" },
      { text: `post: "${postContent.slice(0, 50)}${postContent.length > 50 ? "..." : ""}"`, type: "info" },
      { text: `threshold: ${threshold[0].toFixed(2)}`, type: "info" },
      { text: "embedding post...", type: "system" },
      { text: "searching FAISS index...", type: "system" },
      { text: `Bot B matched: ${(Math.random() * 0.3 + 0.15).toFixed(3)}`, type: "success" },
      { text: `Bot A matched: ${(Math.random() * 0.25 + 0.1).toFixed(3)}`, type: "success" },
      { text: `Bot C matched: ${(Math.random() * 0.2 + 0.05).toFixed(3)}`, type: "info" },
      { text: "routing complete ✓", type: "success" },
    ]

    await simulateTyping(lines)
    setPostContent("")
  }

  const handleGenerate = async () => {
    if (!selectedBot) return

    const lines: TerminalLine[] = [
      { text: "initializing LangGraph engine...", type: "system" },
      { text: `selected bot: ${selectedBot}`, type: "info" },
      { text: "running LangGraph...", type: "system" },
      { text: "Decide Search → analyzing context...", type: "info" },
      { text: "Mock Search → fetching relevant data...", type: "info" },
      { text: "Draft JSON → generating content structure...", type: "info" },
      { text: "generating content...", type: "system" },
      { text: "---", type: "info" },
      {
        text: `Generated Post: "This is an AI-generated insight about the current market trends..."`,
        type: "success",
      },
      { text: "---", type: "info" },
      { text: '{ "type": "post", "bot": "' + selectedBot + '", "status": "generated" }', type: "success" },
      { text: "content generation complete ✓", type: "success" },
    ]

    await simulateTyping(lines)
  }

  const handleDefense = async () => {
    if (!latestReply.trim()) return

    const lines: TerminalLine[] = [
      { text: "analyzing thread...", type: "system" },
      { text: `parent: "${parentPost.slice(0, 30)}..."`, type: "info" },
      { text: `history: ${commentHistory ? "provided" : "none"}`, type: "info" },
      { text: `latest: "${latestReply.slice(0, 30)}..."`, type: "info" },
      { text: "scanning for injection patterns...", type: "system" },
    ]

    const hasInjection = latestReply.toLowerCase().includes("ignore") || latestReply.includes("```")

    if (hasInjection) {
      lines.push(
        { text: "⚠ INJECTION DETECTED!", type: "error" },
        { text: "guardrail active...", type: "warning" },
        { text: "blocking malicious input...", type: "warning" }
      )
    } else {
      lines.push({ text: "no injection patterns found", type: "success" })
    }

    lines.push(
      { text: "generating defense reply...", type: "system" },
      { text: "---", type: "info" },
      {
        text: "Defense Response: Thank you for your input. I can only respond to genuine questions about the topic.",
        type: "success",
      },
      { text: "---", type: "info" },
      { text: "defense analysis complete ✓", type: "success" }
    )

    await simulateTyping(lines)
    setParentPost("")
    setCommentHistory("")
    setLatestReply("")
  }

  return (
    <div className="space-y-6">
      {/* Section 1: Persona Router */}
      <Card className="border-neutral-200 bg-white/80 backdrop-blur-sm transition-shadow hover:shadow-md dark:border-neutral-800 dark:bg-neutral-900/80">
        <CardHeader className="pb-4">
          <div className="flex items-center gap-3">
            <div className="flex size-10 items-center justify-center rounded-lg bg-emerald-100 dark:bg-emerald-900/30">
              <Network className="size-5 text-emerald-600 dark:text-emerald-400" />
            </div>
            <div>
              <CardTitle className="text-lg">1. Persona Router</CardTitle>
              <CardDescription>Route a post through the cognitive mesh</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea
            placeholder="Enter post content to route..."
            value={postContent}
            onChange={(e) => setPostContent(e.target.value)}
            className="min-h-24 resize-none"
          />
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Threshold</span>
              <span className="font-mono text-sm">{threshold[0].toFixed(2)}</span>
            </div>
            <Slider value={threshold} onValueChange={setThreshold} min={0} max={1} step={0.01} className="w-full" />
          </div>
          <Button onClick={handleRoute} disabled={!postContent.trim()} className="w-full">
            Route Through Mesh
          </Button>
        </CardContent>
      </Card>

      {/* Section 2: Content Engine */}
      <Card className="border-neutral-200 bg-white/80 backdrop-blur-sm transition-shadow hover:shadow-md dark:border-neutral-800 dark:bg-neutral-900/80">
        <CardHeader className="pb-4">
          <div className="flex items-center gap-3">
            <div className="flex size-10 items-center justify-center rounded-lg bg-cyan-100 dark:bg-cyan-900/30">
              <Cpu className="size-5 text-cyan-600 dark:text-cyan-400" />
            </div>
            <div>
              <CardTitle className="text-lg">2. Content Engine</CardTitle>
              <CardDescription>Generate content using LangGraph</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <Select value={selectedBot} onValueChange={setSelectedBot}>
            <SelectTrigger>
              <SelectValue placeholder="Select a bot persona" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="bot-a">Bot A - Technical Analyst</SelectItem>
              <SelectItem value="bot-b">Bot B - Creative Writer</SelectItem>
              <SelectItem value="bot-c">Bot C - Data Scientist</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={handleGenerate} disabled={!selectedBot} className="w-full">
            Run LangGraph Engine
          </Button>
        </CardContent>
      </Card>

      {/* Section 3: RAG Defense */}
      <Card className="border-neutral-200 bg-white/80 backdrop-blur-sm transition-shadow hover:shadow-md dark:border-neutral-800 dark:bg-neutral-900/80">
        <CardHeader className="pb-4">
          <div className="flex items-center gap-3">
            <div className="flex size-10 items-center justify-center rounded-lg bg-amber-100 dark:bg-amber-900/30">
              <Shield className="size-5 text-amber-600 dark:text-amber-400" />
            </div>
            <div>
              <CardTitle className="text-lg">3. RAG Defense</CardTitle>
              <CardDescription>Test prompt injection defense</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <Textarea
              placeholder="Parent post content..."
              value={parentPost}
              onChange={(e) => setParentPost(e.target.value)}
              className="min-h-16 resize-none"
            />
            <Textarea
              placeholder="Comment history (optional)..."
              value={commentHistory}
              onChange={(e) => setCommentHistory(e.target.value)}
              className="min-h-16 resize-none"
            />
            <Textarea
              placeholder="Latest reply to analyze..."
              value={latestReply}
              onChange={(e) => setLatestReply(e.target.value)}
              className="min-h-16 resize-none"
            />
          </div>
          <Button onClick={handleDefense} disabled={!latestReply.trim()} className="w-full">
            Test Guardrail
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
