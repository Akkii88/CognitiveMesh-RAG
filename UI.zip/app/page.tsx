"use client"

import { useState } from "react"
import { CRTTerminal, type TerminalLine } from "@/components/crt-terminal"
import { InputSections } from "@/components/input-sections"
import { Button } from "@/components/ui/button"
import { Github, Mail, Zap, Brain, Shield } from "lucide-react"

export default function Home() {
  const [terminalLines, setTerminalLines] = useState<TerminalLine[]>([])
  const [isTyping, setIsTyping] = useState(false)

  const handleAddLines = (newLines: TerminalLine[]) => {
    setTerminalLines((prev) => [...prev, ...newLines])
  }

  const handleClear = () => {
    setTerminalLines([])
  }

  return (
    <main className="min-h-screen bg-gradient-to-b from-neutral-50 to-neutral-100 dark:from-neutral-950 dark:to-neutral-900">
      {/* Hero Section */}
      <section className="px-6 pb-12 pt-16">
        <div className="mx-auto max-w-6xl">
          <div className="grid items-center gap-12 lg:grid-cols-2">
            {/* Left: Title & Description */}
            <div className="space-y-6">
              <div className="inline-flex items-center gap-2 rounded-full bg-emerald-100 px-4 py-1.5 text-sm font-medium text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400">
                <Zap className="size-4" />
                AI Engineering Assignment
              </div>

              <h1 className="text-balance text-4xl font-bold tracking-tight text-neutral-900 dark:text-white sm:text-5xl">
                Cognitive Mesh
                <span className="mt-1 block text-emerald-600 dark:text-emerald-400">Control System</span>
              </h1>

              <p className="max-w-md text-pretty text-lg leading-relaxed text-neutral-600 dark:text-neutral-400">
                A live demonstration of cognitive routing, LangGraph content generation, and RAG defense mechanisms.
                Control the system below and watch execution unfold in real-time.
              </p>

              <div className="flex flex-wrap gap-4">
                <div className="flex items-center gap-2 text-sm text-neutral-600 dark:text-neutral-400">
                  <Brain className="size-4 text-emerald-600 dark:text-emerald-400" />
                  <span>Persona Routing</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-neutral-600 dark:text-neutral-400">
                  <Zap className="size-4 text-cyan-600 dark:text-cyan-400" />
                  <span>LangGraph Engine</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-neutral-600 dark:text-neutral-400">
                  <Shield className="size-4 text-amber-600 dark:text-amber-400" />
                  <span>RAG Defense</span>
                </div>
              </div>

              <div className="flex gap-3 pt-2">
                <Button variant="outline" size="sm" asChild>
                  <a href="https://github.com" target="_blank" rel="noopener noreferrer">
                    <Github className="mr-2 size-4" />
                    View Source
                  </a>
                </Button>
                <Button variant="outline" size="sm" asChild>
                  <a href="mailto:ankitdabur08@gmail.com">
                    <Mail className="mr-2 size-4" />
                    Contact
                  </a>
                </Button>
              </div>
            </div>

            {/* Right: CRT Computer */}
            <div>
              <CRTTerminal lines={terminalLines} isTyping={isTyping} onClear={handleClear} />
            </div>
          </div>
        </div>
      </section>

      {/* Input Sections */}
      <section className="px-6 pb-16">
        <div className="mx-auto max-w-2xl">
          <div className="mb-8 text-center">
            <h2 className="text-xl font-semibold text-neutral-900 dark:text-white">System Controls</h2>
            <p className="mt-1 text-sm text-neutral-600 dark:text-neutral-400">
              Interact with the inputs below to see live execution on the terminal above
            </p>
          </div>

          <InputSections onAddLines={handleAddLines} setIsTyping={setIsTyping} />
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-neutral-200 px-6 py-8 dark:border-neutral-800">
        <div className="mx-auto max-w-6xl text-center">
          <p className="text-sm text-neutral-500 dark:text-neutral-500">
            Built for AI Engineering Assignment | Cognitive Routing + LangGraph + RAG
          </p>
          <p className="mt-1 text-sm text-neutral-400 dark:text-neutral-600">
            Made by Ankit · ankitdabur08@gmail.com
          </p>
        </div>
      </footer>
    </main>
  )
}
